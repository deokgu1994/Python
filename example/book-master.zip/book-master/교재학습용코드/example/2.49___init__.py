from kiwoom.kiwoom import *

class Main():
  def __init__(self):
    print("Main() start")

    Kiwoom()

if __name__ == "__main__":
  Main()
